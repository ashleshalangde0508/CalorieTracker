"""Calories Tracker - Streamlit app.

Features: login/registration, multi-item daily food logging, weekly report with charts,
calories-burned ML predictor, BMI and daily calorie target, model comparison.
"""
import hashlib
import hmac
import json
import secrets
import sqlite3
from contextlib import contextmanager
from datetime import date, datetime, timedelta
from pathlib import Path

import altair as alt
import joblib
import pandas as pd
import streamlit as st

try:
    from zoneinfo import ZoneInfo

    APP_TZ = ZoneInfo("Asia/Kolkata")  # change if you are in another time zone
except Exception:  # time zone database not available
    APP_TZ = None

BASE = Path(__file__).parent
MODEL_PATH = BASE / "best_calories_burned_model.joblib"
META_PATH = BASE / "model_metadata.json"
FOOD_PATH = BASE / "food_nutrition_cleaned.csv"
COMPARE_PATH = BASE / "model_comparison.csv"
DB_PATH = BASE / "calories_tracker.db"

MEAL_TYPES = ["Breakfast", "Lunch", "Snack", "Dinner"]
ACTIVITY_LEVELS = {
    "Sedentary": 1.2,
    "Lightly active": 1.375,
    "Moderately active": 1.55,
    "Very active": 1.725,
    "Extra active": 1.9,
}
DEFAULT_TARGET = 2000
NUTRIENT_COLS = {
    "calories": "Calories_kcal_per_100g",
    "protein": "Protein_g_per_100g",
    "carbs": "Carbohydrates_g_per_100g",
    "fat": "Fat_g_per_100g",
    "fiber": "Fiber_g_per_100g",
}

st.set_page_config(page_title="Calories Tracker", page_icon="🔥", layout="wide")


# ----------------------------------------------------------------------------
# Helpers: time
# ----------------------------------------------------------------------------
def now_local():
    return datetime.now(APP_TZ) if APP_TZ else datetime.now()


def today():
    return now_local().date()


# ----------------------------------------------------------------------------
# Database
# ----------------------------------------------------------------------------
@contextmanager
def db():
    conn = sqlite3.connect(DB_PATH)
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def _one(conn, sql, params=()):
    cur = conn.execute(sql, params)
    row = cur.fetchone()
    if row is None:
        return None
    return dict(zip([c[0] for c in cur.description], row))


def init_db():
    with db() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                salt TEXT NOT NULL,
                password_hash TEXT NOT NULL,
                sex TEXT,
                age INTEGER,
                height_cm REAL,
                weight_kg REAL,
                activity TEXT,
                daily_target INTEGER,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS meals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL REFERENCES users(id),
                log_date TEXT NOT NULL,
                meal_type TEXT NOT NULL,
                food_name TEXT NOT NULL,
                quantity_g REAL NOT NULL,
                calories REAL NOT NULL,
                protein REAL NOT NULL,
                carbs REAL NOT NULL,
                fat REAL NOT NULL,
                fiber REAL NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_meals_user_date ON meals(user_id, log_date);
            """
        )


# ---- users / authentication -------------------------------------------------
def hash_password(password, salt=None):
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 200_000)
    return salt.hex(), digest.hex()


def create_user(username, password):
    salt_hex, hash_hex = hash_password(password)
    try:
        with db() as conn:
            conn.execute(
                "INSERT INTO users (username, salt, password_hash, created_at) VALUES (?, ?, ?, ?)",
                (username, salt_hex, hash_hex, datetime.now().isoformat(timespec="seconds")),
            )
    except sqlite3.IntegrityError:
        return False
    return True


def verify_user(username, password):
    username = username.strip().lower()
    with db() as conn:
        row = _one(
            conn,
            "SELECT id, username, salt, password_hash FROM users WHERE username = ?",
            (username,),
        )
    if row is None:
        return None
    _, digest = hash_password(password, bytes.fromhex(row["salt"]))
    if hmac.compare_digest(digest, row["password_hash"]):
        return {"id": row["id"], "username": row["username"]}
    return None


def get_profile(user_id):
    with db() as conn:
        return (
            _one(
                conn,
                "SELECT sex, age, height_cm, weight_kg, activity, daily_target FROM users WHERE id = ?",
                (user_id,),
            )
            or {}
        )


def save_profile(user_id, sex, age, height_cm, weight_kg, activity, daily_target):
    with db() as conn:
        conn.execute(
            "UPDATE users SET sex=?, age=?, height_cm=?, weight_kg=?, activity=?, daily_target=? WHERE id=?",
            (sex, int(age), float(height_cm), float(weight_kg), activity, int(daily_target), user_id),
        )


# ---- meals -------------------------------------------------------------------
def add_meals(user_id, log_date, items):
    created = datetime.now().isoformat(timespec="seconds")
    rows = [
        (
            user_id,
            log_date.isoformat(),
            it["meal_type"],
            it["food"],
            it["qty"],
            it["calories"],
            it["protein"],
            it["carbs"],
            it["fat"],
            it["fiber"],
            created,
        )
        for it in items
    ]
    with db() as conn:
        conn.executemany(
            "INSERT INTO meals (user_id, log_date, meal_type, food_name, quantity_g, calories, "
            "protein, carbs, fat, fiber, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            rows,
        )


def get_meals(user_id, start, end):
    with db() as conn:
        df = pd.read_sql_query(
            "SELECT id, log_date, meal_type, food_name, quantity_g, calories, protein, carbs, fat, fiber "
            "FROM meals WHERE user_id = ? AND log_date BETWEEN ? AND ? ORDER BY log_date, id",
            conn,
            params=(user_id, start.isoformat(), end.isoformat()),
        )
    df["log_date"] = pd.to_datetime(df["log_date"])
    return df


def delete_meals(user_id, ids):
    if not ids:
        return 0
    marks = ",".join("?" for _ in ids)
    with db() as conn:
        cur = conn.execute(
            f"DELETE FROM meals WHERE user_id = ? AND id IN ({marks})", [user_id, *[int(i) for i in ids]]
        )
        return cur.rowcount


# ----------------------------------------------------------------------------
# Cached data / model loaders
# ----------------------------------------------------------------------------
@st.cache_resource
def load_model():
    return joblib.load(MODEL_PATH)


@st.cache_data
def load_meta():
    with open(META_PATH) as f:
        return json.load(f)


@st.cache_data
def load_food():
    df = pd.read_csv(FOOD_PATH)
    df = df.dropna(subset=["Food_Name"]).copy()
    df["Food_Name"] = df["Food_Name"].astype(str).str.strip()
    df = df.drop_duplicates(subset="Food_Name").set_index("Food_Name")
    return df


def nutrients_for(food_df, name, qty):
    row = food_df.loc[name]
    out = {}
    for key, col in NUTRIENT_COLS.items():
        val = row[col] if col in food_df.columns else 0
        out[key] = round(float(val) * qty / 100.0, 2) if pd.notna(val) else 0.0
    return out


# ----------------------------------------------------------------------------
# Health calculations
# ----------------------------------------------------------------------------
def calculate_bmi(weight_kg, height_cm):
    return weight_kg / ((height_cm / 100) ** 2)


def bmi_category(bmi):
    if bmi < 18.5:
        return "Underweight"
    if bmi < 25:
        return "Normal range"
    if bmi < 30:
        return "Overweight"
    return "Obesity range"


def estimate_daily_calories(sex, age, height_cm, weight_kg, activity):
    sex_term = 5 if sex.lower() == "male" else -161
    ree = 10 * weight_kg + 6.25 * height_cm - 5 * age + sex_term
    return round(ree * ACTIVITY_LEVELS[activity])


# ----------------------------------------------------------------------------
# Callbacks (run before the script reruns, so every tab sees fresh data)
# ----------------------------------------------------------------------------
def save_day_cb(user_id):
    picked = st.session_state.get("picked_foods", [])
    if not picked:
        return
    food_df = load_food()
    items = []
    for name in picked:
        qty = float(st.session_state.get(f"qty_{name}", 100.0))
        meal = st.session_state.get(f"meal_{name}", "Lunch")
        items.append({"food": name, "qty": qty, "meal_type": meal, **nutrients_for(food_df, name, qty)})
    log_date = st.session_state["log_date"]
    add_meals(user_id, log_date, items)
    total = sum(i["calories"] for i in items)
    st.session_state["picked_foods"] = []
    st.session_state["flash_log"] = f"Saved {len(items)} items ({total:.0f} kcal) for {log_date:%d %b %Y}."


def delete_cb(user_id, key):
    ids = st.session_state.get(key, [])
    n = delete_meals(user_id, ids)
    st.session_state[key] = []
    st.session_state["flash_log"] = f"Removed {n} entr{'y' if n == 1 else 'ies'}."


def save_profile_cb(user_id, sex, age, height, weight, activity, target):
    save_profile(user_id, sex, age, height, weight, activity, target)
    st.session_state["flash_profile"] = f"Profile saved. Your daily target is now {int(target)} kcal."


def logout_cb():
    st.session_state.clear()


# ----------------------------------------------------------------------------
# Login / registration page
# ----------------------------------------------------------------------------
def render_auth():
    st.title("🔥 Calories Tracker")
    st.caption("Log in to track your daily food and get a weekly report with charts.")
    _, mid, _ = st.columns([1, 2, 1])
    with mid:
        tab_in, tab_up = st.tabs(["Log in", "Create account"])
        with tab_in:
            with st.form("login_form"):
                username = st.text_input("Username")
                password = st.text_input("Password", type="password")
                submitted = st.form_submit_button("Log in", type="primary")
            if submitted:
                user = verify_user(username, password)
                if user:
                    st.session_state["user"] = user
                    st.rerun()
                else:
                    st.error("Incorrect username or password.")
        with tab_up:
            with st.form("register_form"):
                new_user = st.text_input("Choose a username", help="3+ characters: letters, numbers, . or _")
                new_pass = st.text_input("Choose a password", type="password", help="At least 6 characters")
                confirm = st.text_input("Confirm password", type="password")
                created = st.form_submit_button("Create account", type="primary")
            if created:
                uname = new_user.strip().lower()
                if len(uname) < 3 or not uname.replace("_", "").replace(".", "").isalnum():
                    st.error("Username must be 3+ characters using letters, numbers, '.' or '_'.")
                elif len(new_pass) < 6:
                    st.error("Password must be at least 6 characters.")
                elif new_pass != confirm:
                    st.error("Passwords do not match.")
                elif create_user(uname, new_pass):
                    st.success("Account created. Switch to the 'Log in' tab to sign in.")
                else:
                    st.error("That username is already taken.")


# ----------------------------------------------------------------------------
# Tab: Log my day (several foods at once)
# ----------------------------------------------------------------------------
def default_meal_index():
    hour = now_local().hour
    if hour < 11:
        return 0
    if hour < 16:
        return 1
    if hour < 19:
        return 2
    return 3


def render_log_tab(user_id, target):
    st.subheader("Log what you ate")
    msg = st.session_state.pop("flash_log", None)
    if msg:
        st.success(msg)

    try:
        food_df = load_food()
    except Exception as e:
        st.error(f"Could not load the food data: {e}")
        return

    c1, c2 = st.columns([1, 3])
    with c1:
        log_date = st.date_input(
            "Date", value=today(), max_value=today() + timedelta(days=1), key="log_date"
        )
    with c2:
        picked = st.multiselect(
            "Select everything you ate (2 to 4 items, or more)",
            options=sorted(food_df.index.tolist()),
            key="picked_foods",
            max_selections=10,
            placeholder="Search and select foods",
        )

    if picked:
        h1, h2, h3 = st.columns([3, 1.5, 1.5])
        h1.caption("Food")
        h2.caption("Quantity (grams)")
        h3.caption("Meal")
        rows = []
        for name in picked:
            a, b, c = st.columns([3, 1.5, 1.5])
            a.markdown(f"**{name}**")
            qty = b.number_input(
                "Quantity (g)",
                min_value=1.0,
                max_value=5000.0,
                value=100.0,
                step=10.0,
                key=f"qty_{name}",
                label_visibility="collapsed",
            )
            meal = c.selectbox(
                "Meal",
                MEAL_TYPES,
                index=default_meal_index(),
                key=f"meal_{name}",
                label_visibility="collapsed",
            )
            n = nutrients_for(food_df, name, qty)
            rows.append(
                {
                    "Food": name,
                    "Meal": meal,
                    "Quantity (g)": qty,
                    "Calories (kcal)": n["calories"],
                    "Protein (g)": n["protein"],
                    "Carbs (g)": n["carbs"],
                    "Fat (g)": n["fat"],
                    "Fiber (g)": n["fiber"],
                }
            )
        preview = pd.DataFrame(rows)
        st.dataframe(preview, hide_index=True, width="stretch")

        m = st.columns(5)
        m[0].metric("Calories", f"{preview['Calories (kcal)'].sum():.0f} kcal")
        m[1].metric("Protein", f"{preview['Protein (g)'].sum():.1f} g")
        m[2].metric("Carbs", f"{preview['Carbs (g)'].sum():.1f} g")
        m[3].metric("Fat", f"{preview['Fat (g)'].sum():.1f} g")
        m[4].metric("Fiber", f"{preview['Fiber (g)'].sum():.1f} g")

        existing = get_meals(user_id, log_date, log_date)["calories"].sum()
        after = existing + preview["Calories (kcal)"].sum()
        st.caption(
            f"Already logged for {log_date:%d %b %Y}: {existing:.0f} kcal. "
            f"After saving: {after:.0f} kcal (daily target {target} kcal)."
        )
        st.button("Save to my log", type="primary", on_click=save_day_cb, args=(user_id,))
    else:
        st.info("Pick the foods you ate above. You can add all of them for the day in one go.")

    # Entries already saved for the selected date
    day_df = get_meals(user_id, log_date, log_date)
    if not day_df.empty:
        st.markdown(f"**Logged on {log_date:%d %b %Y}**")
        show = day_df.drop(columns=["id", "log_date"]).rename(
            columns={
                "meal_type": "Meal",
                "food_name": "Food",
                "quantity_g": "Quantity (g)",
                "calories": "Calories (kcal)",
                "protein": "Protein (g)",
                "carbs": "Carbs (g)",
                "fat": "Fat (g)",
                "fiber": "Fiber (g)",
            }
        )
        st.dataframe(show, hide_index=True, width="stretch")
        labels = {
            int(r.id): f"{r.food_name} · {r.quantity_g:.0f} g · {r.calories:.0f} kcal"
            for r in day_df.itertuples()
        }
        del_key = f"to_delete_{log_date.isoformat()}"
        st.multiselect("Remove entries (if you made a mistake)", options=list(labels), format_func=labels.get, key=del_key)
        st.button("Delete selected", on_click=delete_cb, args=(user_id, del_key))


# ----------------------------------------------------------------------------
# Tab: Weekly report
# ----------------------------------------------------------------------------
def week_options():
    t = today()
    monday = t - timedelta(days=t.weekday())
    options = {"Last 7 days": (t - timedelta(days=6), t)}
    for i in range(8):
        start = monday - timedelta(weeks=i)
        end = start + timedelta(days=6)
        label = f"{start:%d %b} - {end:%d %b %Y}" + (" (this week)" if i == 0 else "")
        options[label] = (start, end)
    return options


def build_daily(df, start, end, target):
    days = pd.date_range(start, end)
    sums = df.groupby("log_date")[["calories", "protein", "carbs", "fat", "fiber"]].sum()
    counts = df.groupby("log_date").size()
    daily = sums.reindex(days, fill_value=0.0)
    daily["items"] = counts.reindex(days, fill_value=0).values
    daily.index.name = "date"
    daily = daily.reset_index()
    daily["day"] = daily["date"].dt.strftime("%a %d %b")
    daily["logged"] = daily["items"] > 0

    def status(row):
        if not row["logged"]:
            return "Not logged"
        ratio = row["calories"] / target
        if ratio < 0.9:
            return "Under"
        if ratio <= 1.1:
            return "On target"
        return "Over"

    daily["status"] = daily.apply(status, axis=1)
    return daily.drop(columns=["date"])


def build_insights(daily, df, target, elapsed):
    logged = daily[daily["logged"]]
    n = len(logged)
    out = []
    avg = logged["calories"].mean()
    diff = (avg - target) / target * 100
    out.append(
        f"You logged **{n} of {elapsed}** days. Your average on logged days was **{avg:.0f} kcal** "
        f"against a target of **{target} kcal** ({diff:+.0f}%)."
    )
    if n > 1:
        hi = logged.loc[logged["calories"].idxmax()]
        lo = logged.loc[logged["calories"].idxmin()]
        out.append(
            f"Highest day: **{hi['day']}** ({hi['calories']:.0f} kcal). "
            f"Lowest day: **{lo['day']}** ({lo['calories']:.0f} kcal)."
        )
    counts = logged["status"].value_counts()
    out.append(
        f"Over target: {counts.get('Over', 0)} day(s). On target (within 10%): {counts.get('On target', 0)} day(s). "
        f"Under target: {counts.get('Under', 0)} day(s)."
    )

    macro_kcal = {"Protein": df["protein"].sum() * 4, "Carbs": df["carbs"].sum() * 4, "Fat": df["fat"].sum() * 9}
    total = sum(macro_kcal.values())
    if total > 0:
        pct = {k: v / total * 100 for k, v in macro_kcal.items()}
        ranges = {"Protein": (10, 35), "Carbs": (45, 65), "Fat": (20, 35)}
        flags = []
        for k, (lo_, hi_) in ranges.items():
            if pct[k] < lo_:
                flags.append(f"{k.lower()} is below the usual {lo_}-{hi_}% range")
            elif pct[k] > hi_:
                flags.append(f"{k.lower()} is above the usual {lo_}-{hi_}% range")
        split = ", ".join(f"{k} {v:.0f}%" for k, v in pct.items())
        text = f"Your calories came from: {split}."
        text += (" Note: " + "; ".join(flags) + ".") if flags else " This is within the usual ranges for adults."
        out.append(text)

    fiber_avg = logged["fiber"].mean()
    if fiber_avg < 25:
        out.append(f"Average fiber was **{fiber_avg:.0f} g/day**, below the commonly suggested 25-30 g. More vegetables, fruit, pulses or whole grains can help.")
    else:
        out.append(f"Average fiber was **{fiber_avg:.0f} g/day**, which meets the commonly suggested 25-30 g.")

    by_food = df.groupby("food_name")["calories"].sum().sort_values(ascending=False)
    if len(by_food) and by_food.sum() > 0:
        out.append(
            f"Your biggest calorie source was **{by_food.index[0]}** "
            f"({by_food.iloc[0] / by_food.sum() * 100:.0f}% of the week's calories)."
        )
    if n < elapsed:
        out.append("Some days were not logged. Logging every day gives a more reliable weekly picture.")
    return out


def render_weekly_tab(user_id, target, has_profile_target):
    st.subheader("Weekly report")
    options = week_options()
    choice = st.selectbox("Choose a week", list(options), key="week_choice")
    start, end = options[choice]
    if not has_profile_target:
        st.caption(
            f"You have not set a daily target yet, so {DEFAULT_TARGET} kcal is used. "
            "Set yours in the 'BMI & Daily Target' tab."
        )

    df = get_meals(user_id, start, end)
    if df.empty:
        st.info("No meals logged in this period yet. Use the 'Log My Day' tab to add your food.")
        return

    elapsed = max(1, (min(end, today()) - start).days + 1)
    daily = build_daily(df, start, end, target)
    logged = daily[daily["logged"]]

    m = st.columns(4)
    m[0].metric("Days logged", f"{len(logged)} / {elapsed}")
    m[1].metric("Average per logged day", f"{logged['calories'].mean():.0f} kcal",
                f"{logged['calories'].mean() - target:+.0f} vs target", delta_color="off")
    m[2].metric("Total calories", f"{df['calories'].sum():.0f} kcal")
    m[3].metric("Days on target", f"{(daily['status'] == 'On target').sum()}")

    st.markdown("#### What your week looked like")
    for line in build_insights(daily, df, target, elapsed):
        st.markdown(f"- {line}")
    st.caption("General guidance only, not medical advice.")

    # --- charts
    day_order = daily["day"].tolist()
    status_scale = alt.Scale(
        domain=["Under", "On target", "Over", "Not logged"],
        range=["#4C78A8", "#54A24B", "#E45756", "#BAB0AC"],
    )
    bars = (
        alt.Chart(daily)
        .mark_bar()
        .encode(
            x=alt.X("day:N", sort=day_order, title=None),
            y=alt.Y("calories:Q", title="Calories (kcal)"),
            color=alt.Color("status:N", scale=status_scale, legend=alt.Legend(title="Status")),
            tooltip=["day", alt.Tooltip("calories:Q", format=".0f"), "status"],
        )
    )
    rule = (
        alt.Chart(pd.DataFrame({"target": [target]}))
        .mark_rule(strokeDash=[6, 4], color="#888888", strokeWidth=2)
        .encode(y="target:Q")
    )
    st.altair_chart(
        (bars + rule).properties(title=f"Daily calories vs target ({target} kcal)", height=320),
        width="stretch",
    )

    c1, c2 = st.columns(2)
    with c1:
        macro_df = pd.DataFrame(
            {
                "Macro": ["Protein", "Carbs", "Fat"],
                "kcal": [df["protein"].sum() * 4, df["carbs"].sum() * 4, df["fat"].sum() * 9],
            }
        )
        macro_df["Share"] = macro_df["kcal"] / macro_df["kcal"].sum() if macro_df["kcal"].sum() else 0
        donut = (
            alt.Chart(macro_df)
            .mark_arc(innerRadius=60)
            .encode(
                theta="kcal:Q",
                color=alt.Color("Macro:N"),
                tooltip=["Macro", alt.Tooltip("kcal:Q", format=".0f"), alt.Tooltip("Share:Q", format=".0%")],
            )
            .properties(title="Where your calories came from", height=300)
        )
        st.altair_chart(donut, width="stretch")
    with c2:
        melted = daily.melt(id_vars=["day"], value_vars=["protein", "carbs", "fat"], var_name="Macro", value_name="grams")
        melted["Macro"] = melted["Macro"].str.capitalize()
        stacked = (
            alt.Chart(melted)
            .mark_bar()
            .encode(
                x=alt.X("day:N", sort=day_order, title=None),
                y=alt.Y("grams:Q", title="Grams"),
                color="Macro:N",
                tooltip=["day", "Macro", alt.Tooltip("grams:Q", format=".1f")],
            )
            .properties(title="Daily protein, carbs and fat", height=300)
        )
        st.altair_chart(stacked, width="stretch")

    c3, c4 = st.columns(2)
    with c3:
        by_meal = df.groupby("meal_type")["calories"].sum().reindex(MEAL_TYPES, fill_value=0).reset_index()
        meal_chart = (
            alt.Chart(by_meal)
            .mark_bar()
            .encode(
                x=alt.X("meal_type:N", sort=MEAL_TYPES, title=None),
                y=alt.Y("calories:Q", title="Calories (kcal)"),
                tooltip=["meal_type", alt.Tooltip("calories:Q", format=".0f")],
            )
            .properties(title="Calories by meal", height=300)
        )
        st.altair_chart(meal_chart, width="stretch")
    with c4:
        top = df.groupby("food_name")["calories"].sum().sort_values(ascending=False).head(5).reset_index()
        top_chart = (
            alt.Chart(top)
            .mark_bar()
            .encode(
                y=alt.Y("food_name:N", sort="-x", title=None),
                x=alt.X("calories:Q", title="Calories (kcal)"),
                tooltip=["food_name", alt.Tooltip("calories:Q", format=".0f")],
            )
            .properties(title="Top 5 foods by calories", height=300)
        )
        st.altair_chart(top_chart, width="stretch")

    with st.expander("Day-by-day numbers and all entries"):
        table = daily[["day", "items", "calories", "protein", "carbs", "fat", "fiber", "status"]].rename(
            columns={
                "day": "Day", "items": "Items", "calories": "Calories (kcal)", "protein": "Protein (g)",
                "carbs": "Carbs (g)", "fat": "Fat (g)", "fiber": "Fiber (g)", "status": "Status",
            }
        )
        st.dataframe(table.round(1), hide_index=True, width="stretch")
        entries = df.drop(columns=["id"]).copy()
        entries["log_date"] = entries["log_date"].dt.strftime("%Y-%m-%d")
        st.dataframe(entries, hide_index=True, width="stretch")
        st.download_button(
            "Download this week as CSV",
            entries.to_csv(index=False).encode("utf-8"),
            file_name=f"calories_{start.isoformat()}_to_{end.isoformat()}.csv",
            mime="text/csv",
        )


# ----------------------------------------------------------------------------
# Tab: Calories burned predictor (ML model)
# ----------------------------------------------------------------------------
def render_predictor_tab():
    st.subheader("How many calories did you burn during your workout?")
    try:
        model = load_model()
        meta = load_meta()
    except Exception as e:
        st.error(f"Could not load the model: {e}")
        return

    features = meta["features"]
    ranges = {
        "Age_years": (10, 100, 25),
        "Height_cm": (100, 220, 170),
        "Weight_kg": (30, 200, 70),
        "Duration_min": (1, 300, 30),
        "Heart_Rate_bpm": (40, 220, 110),
        "Body_Temp_C": (35.0, 42.0, 37.5),
    }
    values = {}
    cols = st.columns(3)
    i = 0
    for feat in features:
        if feat == "BMI":
            continue  # computed below
        with cols[i % 3]:
            if feat == "Gender":
                values[feat] = st.selectbox("Gender", ["Male", "Female"], key="pred_gender")
            elif feat in ranges:
                lo, hi, dflt = ranges[feat]
                if isinstance(lo, float):
                    values[feat] = st.number_input(feat, lo, hi, float(dflt), step=0.1, key=f"pred_{feat}")
                else:
                    values[feat] = st.number_input(feat, lo, hi, dflt, step=1, key=f"pred_{feat}")
            else:
                values[feat] = st.number_input(feat, value=0.0, key=f"pred_{feat}")
        i += 1

    if "BMI" in features and "Height_cm" in values and "Weight_kg" in values:
        values["BMI"] = calculate_bmi(values["Weight_kg"], values["Height_cm"])
        st.info(f"BMI (auto-calculated): {values['BMI']:.2f}")

    if st.button("Predict calories burned", type="primary"):
        row = pd.DataFrame([values])[features]
        for c in row.columns:
            if row[c].dtype == object:
                row[c] = row[c].astype(object)
        pred = float(model.predict(row)[0])
        st.success(f"Estimated calories burned: **{pred:.0f} kcal**")
        st.caption(f"Model: {meta['best_model']} | Test MAE: {meta['test_MAE']:.2f} kcal")


# ----------------------------------------------------------------------------
# Tab: BMI and daily target (saved to profile)
# ----------------------------------------------------------------------------
def clip(value, lo, hi, fallback):
    try:
        return max(lo, min(hi, value))
    except TypeError:
        return fallback


def render_profile_tab(user_id, profile):
    st.subheader("BMI and daily calorie target")
    msg = st.session_state.pop("flash_profile", None)
    if msg:
        st.success(msg)

    sex_options = ["Male", "Female"]
    act_options = list(ACTIVITY_LEVELS)
    c1, c2, c3 = st.columns(3)
    with c1:
        sex = st.selectbox(
            "Sex", sex_options,
            index=sex_options.index(profile["sex"]) if profile.get("sex") in sex_options else 0,
            key="sex3",
        )
        age = st.number_input("Age (years)", 10, 100, int(clip(profile.get("age"), 10, 100, 25)), key="age3")
    with c2:
        height = st.number_input(
            "Height (cm)", 100, 220, int(round(clip(profile.get("height_cm"), 100, 220, 170))), key="h3"
        )
        weight = st.number_input(
            "Weight (kg)", 30.0, 200.0, float(clip(profile.get("weight_kg"), 30.0, 200.0, 70.0)), step=0.5, key="w3"
        )
    with c3:
        activity = st.selectbox(
            "Activity level", act_options,
            index=act_options.index(profile["activity"]) if profile.get("activity") in act_options else 2,
            key="act3",
        )

    bmi = calculate_bmi(weight, height)
    est = estimate_daily_calories(sex, age, height, weight, activity)
    m1, m2 = st.columns(2)
    m1.metric("BMI", f"{bmi:.1f}", bmi_category(bmi), delta_color="off")
    m2.metric("Estimated daily energy needs", f"{est} kcal/day")
    st.caption("Mifflin-St Jeor formula with an activity multiplier. BMI is a screening tool only.")

    st.markdown("#### Your daily calorie target")
    target = st.number_input(
        "Daily target (kcal). Start from the estimate above, or set your own.",
        min_value=800, max_value=6000, value=int(clip(est, 800, 6000, DEFAULT_TARGET)), step=50, key="target3",
    )
    if profile.get("daily_target"):
        st.caption(f"Currently saved target: {int(profile['daily_target'])} kcal")
    st.button(
        "Save profile and target",
        type="primary",
        on_click=save_profile_cb,
        args=(user_id, sex, age, height, weight, activity, target),
    )


# ----------------------------------------------------------------------------
# Tab: Model performance
# ----------------------------------------------------------------------------
def render_model_tab():
    st.subheader("Model comparison")
    if COMPARE_PATH.exists():
        comp = pd.read_csv(COMPARE_PATH)
        st.dataframe(comp, hide_index=True, width="stretch")
        if {"Model", "RMSE"}.issubset(comp.columns):
            st.bar_chart(comp.set_index("Model")["RMSE"])
    try:
        meta = load_meta()
    except Exception as e:
        st.error(f"Could not load model details: {e}")
        return
    st.write(
        f"**Selected model:** {meta['best_model']}  \n"
        f"**MAE:** {meta['test_MAE']:.3f} | **RMSE:** {meta['test_RMSE']:.3f} | **R²:** {meta['test_R2']:.4f}"
    )


# ----------------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------------
init_db()

if "user" not in st.session_state:
    render_auth()
    st.stop()

user = st.session_state["user"]
profile = get_profile(user["id"])
target = int(profile.get("daily_target") or DEFAULT_TARGET)

with st.sidebar:
    st.markdown(f"Logged in as **{user['username']}**")
    st.button("Log out", on_click=logout_cb)

st.title("🔥 Calories Tracker")
st.caption(
    "The ML model predicts calories **burned**. Calories **eaten** come from the food database. "
    "These are educational estimates, not medical advice."
)

tab_log, tab_week, tab_burn, tab_profile, tab_model = st.tabs(
    ["Log My Day", "Weekly Report", "Calories Burned Predictor", "BMI & Daily Target", "Model Performance"]
)
with tab_log:
    render_log_tab(user["id"], target)
with tab_week:
    render_weekly_tab(user["id"], target, bool(profile.get("daily_target")))
with tab_burn:
    render_predictor_tab()
with tab_profile:
    render_profile_tab(user["id"], profile)
with tab_model:
    render_model_tab()
